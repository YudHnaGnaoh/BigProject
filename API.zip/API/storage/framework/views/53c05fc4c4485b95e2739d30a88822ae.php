<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h3 style="color: red">Bạn đã được xếp lớp với thông tin khóa học như sau:</h3>
    <h4 style="color: black">
        Tên học sinh: <?php echo e($mailData['studentName']); ?>

    </h4>
    <h4 style="color: black">
        Khối: <?php echo e($mailData['grade']); ?>

    </h4> <h4 style="color: black">
        Tên lớp: <?php echo e($mailData['courseName']); ?>

    </h4>
    <h4 style="color: black">
        Tên giáo viên lớp: <?php echo e($mailData['teacher']); ?>

    </h4>
    <h4 style="color: black">
        
        Lịch học: <?php echo e($mailData['schedule']); ?></div>
    </h4>
    <h4 style="color: black">
        Số buổi tổng cộng: <?php echo e($mailData['duration']); ?> buổi
    </h4>
</body>
</html>
<?php /**PATH D:\GitHub Class\CODI_Project\API\resources\views/mail/mail2.blade.php ENDPATH**/ ?>